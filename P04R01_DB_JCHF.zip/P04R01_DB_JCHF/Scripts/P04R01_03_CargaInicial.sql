--Script de: JOSMAR CALEB HERRERA FRANCISCO
--
--
-- Instrucciones: Ejecuta este script una sola vez para poblar la base de datos CafeteriaV1
--               con datos de prueba (INSERTs, UPDATEs y DELETEs sobre las tablas principales).
--               Asegúrate de haber creado previamente las tablas con su respectivo script.
--
--
--
-- NOTA: Verificar si la base de datos ya existe antes de crearla.
--
USE [CafeteriaV1]
GO
-- 1. INSERTS 
-- _________________________________________________________________________________
-- PRODUCTOS
INSERT INTO Productos (Nombre, Categoria, Precio, Stock) VALUES 
('Latte de Vainilla', 'Bebidas', 62.00, 75),
('Croissant de Mantequilla', 'Repostería', 48.00, 50),
('Smoothie de Fresa', 'Bebidas', 70.00, 40),
('Sándwich de Jamón', 'Comida', 95.00, 25),
('Chocolate Caliente', 'Bebidas', 45.00, 90);

-- CLIENTES 
INSERT INTO Clientes (Nombre, Email, Telefono) VALUES 
('Rodrigo Fuentes', 'rodrigo.fuentes@gmail.com', '7221045678'),
('Valentina Cruz', 'vale.cruz@hotmail.com', '5531987654'),
('Miguel Ángel Reyes', 'mreyes@outlook.com', '7471002233'),
('Fernanda Ortega', 'fer.ortega@gmail.com', '5519876541'),
('Daniela Ramos', 'daniela.ramos@gmail.com', '7228765432');

-- PEDIDOS
INSERT INTO Pedidos (ClienteID, Total, Estado) VALUES 
(1, 107.00, 'Completado'),
(2, 95.00, 'Pendiente'),
(3, 140.00, 'En Proceso'),
(4, 48.00, 'Cancelado'),
(5, 115.00, 'Completado');

-- DETALLES DE PEDIDO
INSERT INTO DetallesPedido (PedidoID, ProductoID, Cantidad, PrecioUnitario) VALUES 
(1, 1, 1, 62.00), 
(2, 4, 1, 95.00), 
(3, 3, 2, 70.00), 
(4, 2, 1, 48.00), 
(5, 5, 2, 45.00); 

SELECT * FROM DetallesPedido




-- 2. UPDATES 
-- _________________________________________________________________________________
-- PRODUCTOS
--UPDATE
--SELECT * FROM
Productos SET Precio = 65.00 WHERE ProductoID = 1;

--UPDATE
--SELECT * FROM
Productos SET Stock = Stock - 10 WHERE Categoria = 'Bebidas';

--UPDATE
--SELECT * FROM
Productos SET Nombre = 'Croissant Premium' WHERE ProductoID = 2;

--UPDATE
--SELECT * FROM
Productos SET Categoria = 'Bebidas Frías' WHERE Nombre = 'Smoothie de Fresa';

--UPDATE
--SELECT * FROM
Productos SET Precio = 40.00 WHERE Stock > 80;



-- CLIENTES
--UPDATE
--SELECT * FROM
Clientes SET Email = 'rodrigo.f.nuevo@gmail.com' WHERE ClienteID = 1;

--UPDATE
--SELECT * FROM
Clientes SET Telefono = '7221099999' WHERE ClienteID = 2;

--UPDATE
--SELECT * FROM
Clientes SET Nombre = 'M. Ángel Reyes Torres' WHERE ClienteID = 3;

--UPDATE
--SELECT * FROM
Clientes SET Email = 'fernanda.ortega.mx@gmail.com' WHERE ClienteID = 4;

--UPDATE
--SELECT * FROM
Clientes SET Telefono = '5500112233' WHERE ClienteID = 5;



-- PEDIDOS
--UPDATE
--SELECT * FROM
Pedidos SET Estado = 'Completado' WHERE PedidoID = 2;

--UPDATE
--SELECT * FROM
Pedidos SET Total = 120.00 WHERE PedidoID = 2;

--UPDATE
--SELECT * FROM
Pedidos SET Estado = 'Completado' WHERE PedidoID = 3;

--UPDATE
--SELECT * FROM
Pedidos SET Fecha = GETDATE() WHERE Estado = 'En Proceso';

--UPDATE
--SELECT * FROM
Pedidos SET Total = Total * 0.85 WHERE Estado = 'Cancelado'; 



-- DETALLES
--UPDATE
--SELECT * FROM
DetallesPedido SET Cantidad = 2 WHERE DetalleID = 1;

--UPDATE
--SELECT * FROM
DetallesPedido SET PrecioUnitario = 65.00 WHERE ProductoID = 1;

--UPDATE
--SELECT * FROM
DetallesPedido SET Cantidad = 3 WHERE PedidoID = 3 AND ProductoID = 3;

--UPDATE
--SELECT * FROM
DetallesPedido SET PrecioUnitario = 42.00 WHERE DetalleID = 5;

--UPDATE
--SELECT * FROM
DetallesPedido SET Cantidad = Cantidad + 1 WHERE DetalleID = 4;




-- 3. DELETES
-- _________________________________________________________________________________
--DELETE 
--SELECT *
FROM DetallesPedido WHERE DetalleID IN (1, 2, 3, 4, 5);

--DELETE 
--SELECT *
FROM Pedidos WHERE PedidoID IN (1, 2, 3, 4, 5);

--DELETE 
--SELECT *
DELETE FROM Clientes WHERE ClienteID IN (1, 2, 3, 4, 5);

--DELETE 
--SELECT *
DELETE FROM Productos WHERE ProductoID IN (1, 2, 3, 4, 5);

PRINT 'Operaciones ejecutadas exitosamente';