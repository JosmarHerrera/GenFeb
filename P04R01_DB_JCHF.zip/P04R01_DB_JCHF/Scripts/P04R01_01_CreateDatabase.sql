--Script de: JOSMAR CALEB HERRERA FRANCISCO
--
--
-- Instrucciones: Ejecuta este sql una vez si no la haz creado con anterioridad
--
--
--
-- NOTA: Verificar si la base de datos ya existe antes de crearla
--
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'CafeteriaV1')
BEGIN
    CREATE DATABASE CafeteriaV1;
END
GO

USE CafeteriaV1;
GO