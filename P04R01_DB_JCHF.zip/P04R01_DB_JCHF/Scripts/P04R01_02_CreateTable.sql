--Script de: JOSMAR CALEB HERRERA FRANCISCO
--
--
-- Instrucciones: Al cargar este sql una sola vez, se crear�n 4 tablas.
--
--
--
--
-- NOTA: Verificar si las tablas ya existen antes de crearlas.
--

USE CafeteriaV1;
GO

-- TABLA PERTENECIENTE A PRODUCTOS
BEGIN TRY
    BEGIN TRANSACTION

    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Productos')
    BEGIN
        CREATE TABLE [Productos] (
            ProductoID INT PRIMARY KEY IDENTITY(1,1),
            Nombre NVARCHAR(100) NOT NULL,
            Categoria NVARCHAR(50) NOT NULL,
            Precio DECIMAL(10,2) NOT NULL,
            Stock INT DEFAULT 0,
            FechaCreacion DATETIME DEFAULT GETDATE()
        );
        PRINT 'Tabla de Productos fue creada correctamente'
    END
    ELSE
        PRINT 'La tabla Productos ya existe...'


    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
    PRINT 'Error al crear la tabla Productos - analiza tu error'
    PRINT ERROR_MESSAGE()
END CATCH
GO


-- TABLA PERTENECIENTE A CLIENTES
GO
BEGIN TRY
    BEGIN TRANSACTION

    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Clientes')
    BEGIN
        CREATE TABLE Clientes (
            ClienteID INT PRIMARY KEY IDENTITY(1,1),
            Nombre NVARCHAR(100) NOT NULL,
            Email NVARCHAR(100),
            Telefono NVARCHAR(15)
        );
        PRINT 'Tabla de Clientes fue creada correctamente'
    END
    ELSE
        PRINT 'La tabla Clientes ya existe...'

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
    PRINT 'Error al crear la tabla Clientes - analiza tu error'
    PRINT ERROR_MESSAGE()
END CATCH
GO


-- TABLA PERTENECIENTE A PEDIDOS
GO
BEGIN TRY
    BEGIN TRANSACTION

    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Pedidos')
    BEGIN
        CREATE TABLE Pedidos (
            PedidoID INT PRIMARY KEY IDENTITY(1,1),
            ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
            Fecha DATETIME DEFAULT GETDATE(),
            Total DECIMAL(10,2) NOT NULL,
            Estado NVARCHAR(20) DEFAULT 'Pendiente'
        );
        PRINT 'Tabla de Pedidos fue creada correctamente'
    END
    ELSE
        PRINT 'La tabla Pedidos ya existe...'

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
    PRINT 'Error al crear la tabla Pedidos - analiza tu error'
    PRINT ERROR_MESSAGE()
END CATCH
GO


-- TABLA PERTENECIENTE A DETALLESPEDIDO
GO
BEGIN TRY
    BEGIN TRANSACTION

    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'DetallesPedido')
    BEGIN
        CREATE TABLE DetallesPedido (
            DetalleID INT PRIMARY KEY IDENTITY(1,1),
            PedidoID INT FOREIGN KEY REFERENCES Pedidos(PedidoID),
            ProductoID INT FOREIGN KEY REFERENCES Productos(ProductoID),
            Cantidad INT NOT NULL,
            PrecioUnitario DECIMAL(10,2) NOT NULL
        );
        PRINT 'Tabla de DetallesPedido fue creada correctamente'
    END
    ELSE
        PRINT 'La tabla DetallesPedido ya existe...'

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
    PRINT 'Error al crear la tabla DetallesPedido - analiza tu error'
    PRINT ERROR_MESSAGE()
END CATCH
GO


-- NECESARIO PARA UNIR DATOS EN TABLAS.
-- AGREGAR FOREIGN KEY A PEDIDOS
GO
BEGIN TRY
    BEGIN TRANSACTION

    IF NOT EXISTS (SELECT * FROM sys.foreign_keys  WHERE name = 'FK_Pedidos_Clientes')
    BEGIN
        ALTER TABLE Pedidos ADD CONSTRAINT FK_Pedidos_Clientes
        FOREIGN KEY (ClienteID) REFERENCES Clientes(ClienteID);

        PRINT 'Foreign Key FK_Pedidos_Clientes agregada correctamente, no volver a ejecutar.'
    END
    ELSE
        PRINT 'La Foreign Key FK_Pedidos_Clientes ya existe...'

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
    PRINT 'Error al agregar la Foreign Key - analiza tu error'
    PRINT ERROR_MESSAGE()
END CATCH
GO
