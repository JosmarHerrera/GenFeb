/**
 * ─────────────────────────────────────────────────────
 *  Josmar · Motor de conversión de divisas
 *  48 funciones jQuery — todas comentadas en español
 * ─────────────────────────────────────────────────────
 */

// 1. ready(): Espera a que el DOM esté completamente cargado antes de ejecutar el código
$(document).ready(function () {

    const API_KEY = 'f8b9ca5879111e54f4a3368c';

    const $card      = $("#mainCard");
    const $form      = $("#converterForm");
    const $amount    = $("#amountInput");
    const $from      = $("#currencyFrom");
    const $to        = $("#currencyTo");
    const $btn       = $("#convertBtn");
    const $resultBox = $("#resultBox");
    const $content   = $("#resultContent");


    // ══ CARGA INICIAL DE MONEDAS ══════════════════════════════

    // 2. ajax(): Llama a la API para obtener el listado completo de monedas del mundo
    $.ajax({
        url: `https://v6.exchangerate-api.com/v6/${API_KEY}/codes`,
        method: "GET",
        success: function (data) {
            let opciones = data.supported_codes
                .map(m => `<option value="${m[0]}">${m[0]} — ${m[1]}</option>`)
                .join("");

            // 3. html(): Reemplaza el contenido de ambos selectores con las monedas cargadas
            $from.html(opciones);
            $to.html(opciones);

            // 4. val(): Asigna USD al selector de origen y MXN al de destino por defecto
            $from.val("USD");
            $to.val("MXN");
        }
    });


    // ══ BOTONES DE MONTO RÁPIDO ═══════════════════════════════

    // 5. click(): Detecta el clic sobre cualquier botón de monto rápido
    $(".quick-btn").click(function () {

        // val(): Escribe el monto del botón pulsado en el campo de entrada
        $amount.val($(this).data("amount"));

        // 6. removeClass(): Quita la marca visual de todos los botones rápidos
        $(".quick-btn").removeClass("active");

        // 7. addClass(): Resalta el botón que se acaba de pulsar
        $(this).addClass("active");

        // 8. attr(): Lee el atributo data-amount del botón para registrarlo en consola
        console.log("Monto rápido elegido:", $(this).attr("data-amount"));

        // 9. focus(): Mueve el foco al campo de monto para que el usuario pueda editarlo
        $amount.focus();
    });


    // ══ BOTÓN DE INTERCAMBIO ══════════════════════════════════

    // click(): Detecta el clic en el botón de swap para invertir las monedas
    $("#swapBtn").click(function () {

        // val(): Guarda los valores actuales y los cruza entre los dos selectores
        const tmp = $from.val();
        $from.val($to.val());
        $to.val(tmp);

        // 10. parent(): Sube al contenedor del botón swap y registra su clase en consola
        console.log("Swap desde:", $(this).parent().attr("class"));

        // 11. text(): Actualiza el subtítulo de la tarjeta confirmando el intercambio
        $("#cardSub").text(`Par invertido: ${$from.val()} ↔ ${$to.val()}`);
    });


    // ══ EVENTOS DE TECLADO Y FOCO EN EL CAMPO DE MONTO ═══════

    // 12. keyup(): Con cada tecla liberada actualiza el subtítulo en tiempo real
    $amount.keyup(function () {
        const v = $(this).val();
        // text(): Escribe en el subtítulo el monto que el usuario va escribiendo
        $("#cardSub").text(v ? `Escribiendo: ${v}` : "Conversor de divisas en tiempo real");
    });

    // 13. blur(): Cuando el usuario abandona el campo, valida si el valor es correcto
    $amount.blur(function () {
        if (!$(this).val() || parseFloat($(this).val()) <= 0) {
            // addClass(): Pone borde rojo si el campo quedó vacío o con valor inválido
            $(this).addClass("input-error");
        } else {
            // removeClass(): Pone borde verde si el valor es válido
            $(this).removeClass("input-error").addClass("field-ok");
        }
    });

    // focus(): Limpia los estilos de validación al volver a hacer clic en el campo
    $amount.focus(function () {
        $(this).removeClass("input-error field-ok");
    });

    // 14. focusout(): Registra en consola el valor final del campo al perder el foco
    $amount.focusout(function () {
        console.log("Valor capturado al salir del campo:", $(this).val());
    });

    // 15. dblclick(): Doble clic en el campo borra su contenido por completo
    $amount.dblclick(function () {
        // val(): Vacía el campo al hacer doble clic
        $(this).val("");
        // removeClass(): Quita cualquier clase de estado anterior
        $(this).removeClass("input-error field-ok active");
    });


    // ══ EVENTOS SOBRE LOS SELECTORES ═════════════════════════

    // 16. change(): Al cambiar la moneda de destino, avisa que hay que recalcular
    $to.change(function () {
        if ($resultBox.is(":visible")) {
            // html(): Reemplaza el contenido del resultado con el aviso de recálculo
            $content.html("<p style='color:var(--amber);font-size:0.85rem;'><i class='fas fa-sync-alt'></i> Moneda cambiada — vuelve a convertir</p>");
        }
    });

    // change(): Al cambiar la moneda de origen, actualiza el subtítulo
    $from.change(function () {
        // text(): Notifica en el subtítulo que el par de origen cambió
        $("#cardSub").text(`Origen cambiado a ${$(this).val()} — recalcula para actualizar.`);
    });


    // ══ EVENTOS DE RATÓN SOBRE LA TARJETA ════════════════════

    // 17. mouseover(): Al entrar el cursor en la tarjeta, intensifica su sombra
    $card.mouseover(function () {
        // 18. css(): Aplica una sombra más pronunciada como feedback visual
        $(this).css("box-shadow", "0 28px 65px rgba(0,0,0,0.65)");
    });

    // 19. mouseleave(): Al salir el cursor de la tarjeta, restaura la sombra original
    $card.mouseleave(function () {
        $(this).css("box-shadow", "0 20px 50px rgba(0,0,0,0.5)");
    });

    // 20. mouseout(): Al salir de la tarjeta también restaura su color de borde
    $card.mouseout(function () {
        $(this).css("border-color", "var(--border)");
    });

    // 21. hover(): Al pasar el cursor por los botones rápidos, oscurece su fondo levemente
    $(".quick-btn").hover(
        function () { $(this).css("background", "rgba(249,115,22,0.08)"); },  // Al entrar
        function () { $(this).css("background", "var(--field)"); }            // Al salir
    );

    // dblclick(): Doble clic sobre el resultado lo colapsa o expande
    $resultBox.dblclick(function () {
        // 22. slideToggle(): Contrae o despliega el contenido del resultado con animación
        $content.slideToggle(280);
    });


    // ══ ENVÍO DEL FORMULARIO ══════════════════════════════════

    // 23. submit(): Captura el envío del formulario para evitar la recarga de la página
    $form.submit(function (e) {
        e.preventDefault();
        convertir();
    });


    // ══ FUNCIÓN PRINCIPAL: CONVERTIR ══════════════════════════

    function convertir() {

        // val(): Lee el monto y las monedas elegidas por el usuario
        const monto = parseFloat($amount.val());
        const desde = $from.val();
        const hacia = $to.val();

        if (!monto || monto <= 0 || !desde || !hacia) {
            // 24. empty(): Borra el contenido previo del panel de resultado
            $content.empty();
            // text(): Escribe el mensaje de error en el panel
            $content.text("⚠  Ingresa un monto válido para continuar.");
            $content.css("color", "var(--error)");
            // 25. show(): Muestra la caja para que el error sea visible
            $resultBox.show();
            // addClass(): Activa la animación de sacudida sobre la caja
            $resultBox.addClass("shake");
            setTimeout(() => $resultBox.removeClass("shake"), 400);
            return;
        }

        // 26. slideUp(): Desliza hacia arriba el botón mientras se espera la respuesta
        $btn.slideUp(250);

        // ajax(): Consulta la API con la moneda origen para obtener las tasas actuales
        $.ajax({
            url: `https://v6.exchangerate-api.com/v6/${API_KEY}/latest/${desde}`,
            method: "GET",
            success: function (data) {
                const tasa  = data.conversion_rates[hacia];
                const total = (monto * tasa).toFixed(4);
                mostrarResultado(monto, desde, hacia, tasa, total);
            },
            error: function () {
                $content.text("Error al conectar con la API. Intenta de nuevo.");
                $content.css("color", "var(--error)");
                $resultBox.show();
            },
            complete: function () {
                // 27. delay(): Espera un momento antes de volver a mostrar el botón
                // 28. fadeIn(): El botón reaparece con un fundido suave
                $btn.delay(400).fadeIn(350);
            }
        });
    }


    // ══ FUNCIÓN: MOSTRAR RESULTADO ════════════════════════════

    function mostrarResultado(monto, desde, hacia, tasa, total) {

        // empty(): Limpia el resultado anterior antes de pintar el nuevo
        $content.empty();

        // html(): Inyecta el HTML completo del resultado dentro de la caja
        $content.html(`
            <div class="result-amount">${parseFloat(total).toLocaleString()} ${hacia}</div>
            <p class="result-label">${monto.toLocaleString()} ${desde}</p>
            <p class="result-rate">1 ${desde} = ${tasa.toFixed(6)} ${hacia}</p>
        `);
        $content.css("color", "var(--text)");

        // show(): Hace visible la caja de resultado
        $resultBox.show();

        // text(): Actualiza el subtítulo con el resumen de la última conversión
        $("#cardSub").text(`${monto} ${desde} → ${total} ${hacia}`);

        aplicarEfectos(tasa, desde, hacia);
    }


    // ══ EFECTOS POST-CONVERSIÓN ═══════════════════════════════

    function aplicarEfectos(tasa, desde, hacia) {

        // 29. append(): Agrega la hora exacta de la consulta al final de la caja
        $resultBox.append(
            `<p id='ts' style='font-size:0.7rem;color:var(--muted);margin-top:10px;'>
                <i class='fas fa-clock'></i> Consultado a las ${new Date().toLocaleTimeString()}
            </p>`
        );

        // 30. after(): Inserta una nota orientativa justo después de la caja de resultado
        $resultBox.after(
            "<p id='nota' style='text-align:center;font-size:0.7rem;color:var(--muted);margin-top:6px;'>" +
            "IMPORTANTE: Tasas orientativas. No constituyen asesoría financiera.</p>"
        );

        // 31. before(): Inserta un separador fino justo antes de la caja de resultado
        $resultBox.before(
            "<hr id='sep' style='border:none;border-top:1px solid var(--border);margin:10px 0;'>"
        );

        // 32. appendTo(): Mueve la nota orientativa al interior de la caja de resultado
        $("#nota").appendTo($resultBox);

        // attr(): Lee el ID de la caja de resultado y lo registra en consola
        console.log("Caja de resultado ID:", $resultBox.attr("id"));

        // css(): Resalta el borde de la caja con tono naranja tras el éxito
        $resultBox.css("border-color", "rgba(249,115,22,0.4)");

        // 33. fadeOut(): La nota orientativa se desvanece sola después de 4 segundos
        $("#nota").fadeOut(4000, function () { $(this).remove(); });

        // 34. fadeTo(): El separador baja su opacidad gradualmente hasta casi desaparecer
        $("#sep").fadeTo("slow", 0.2);

        // 35. hide(): Oculta la marca de tiempo antes de animarla con slideDown
        $("#ts").hide();

        // 36. slideDown(): Despliega la marca de tiempo con una animación suave hacia abajo
        $("#ts").slideDown(600);

        // 37. height(): Ajusta la altura de la caja automáticamente según su contenido
        $resultBox.height("auto");

        // 38. width(): Confirma que la caja ocupe el 100% del ancho disponible
        $resultBox.width("100%");

        // removeClass(): Quita cualquier clase de error que pudiera tener la caja
        $resultBox.removeClass("shake input-error");

        // 39. toggleClass(): Alterna el efecto de brillo naranja en la caja de resultado
        $resultBox.toggleClass("glow");

        // 40. hasClass(): Si el brillo está activo, refuerza la sombra de la caja
        if ($resultBox.hasClass("glow")) {
            $resultBox.css("box-shadow", "0 0 22px rgba(249,115,22,0.15)");
        }

        // parent(): Sube al elemento padre de la caja (la tarjeta) y ajusta su padding
        $resultBox.parent().css("padding-bottom", "38px");

        // 41. next(): Selecciona el elemento justo después del separador y le añade margen
        $("#sep").next().css("margin-top", "12px");

        // 42. nextAll(): Selecciona todos los nodos que vengan después de la zona temporal
        // 43. remove(): Los elimina para evitar que se acumulen en conversiones seguidas
        $(".temp-zone").nextAll("[id='nota']").remove();

        // 44. position(): Calcula la posición exacta de la caja en pantalla
        const pos = $resultBox.position();
        console.log(`Caja de resultado: top=${Math.round(pos.top)}px, left=${Math.round(pos.left)}px`);

        // 45. removeAttr(): Quita el placeholder del campo monto una vez convertido
        $amount.removeAttr("placeholder");

        // 46. toggle(): Reinicia el estado visual de la marca de tiempo (oculta y muestra)
        $("#ts").toggle().toggle();

        // slideToggle(): La marca de tiempo aparece con una animación de doble rebote
        $("#ts").slideToggle(140).slideToggle(360);

        // 47. each(): Recorre cada botón rápido y resalta el que coincide con el monto actual
        $(".quick-btn").each(function () {
            const v = parseFloat($(this).data("amount").toString().replace(",", ""));
            // css(): Resalta con naranja el botón que corresponde al monto convertido
            $(this).css("border-color", v === parseFloat($amount.val()) ? "var(--orange)" : "var(--border)");
        });

        // 48. length: Cuenta cuántas opciones de moneda hay en el selector destino
        console.log("Total de monedas disponibles:", $to.find("option").length);

        // blur(): Al perder el foco el campo monto, restaura su color de fondo
        $amount.blur(function () { $(this).css("background", "var(--field)"); });

        // focus(): Al volver a escribir, oscurece el fondo del campo monto
        $amount.focus(function () { $(this).css("background", "#2a3040"); });

        // focusout(): Confirma en consola cuando el campo monto queda libre
        $amount.focusout(function () {
            console.log("Campo monto liberado con valor:", $(this).val());
        });

        // dblclick(): Doble clic sobre el ícono lo hace parpadear
        $(".card-icon").dblclick(function () {
            // fadeOut() + fadeIn(): El ícono desaparece y reaparece como pulso
            $(this).fadeOut(200).fadeIn(450);
        });

        // hover(): Al pasar el cursor por el botón Convertir, cambia el color del ícono
        $btn.hover(
            function () { $(this).find("i").css("color", "rgba(255,255,255,0.6)"); },
            function () { $(this).find("i").css("color", "white"); }
        );

        // mouseleave(): Al retirar el cursor de la caja resultado, restaura su borde
        $resultBox.mouseleave(function () {
            $(this).css("border-color", "rgba(249,115,22,0.4)");
        });

        // mouseout(): Al sacar el cursor del selector destino, restaura su borde
        $to.mouseout(function () { $(this).css("border-color", "var(--border)"); });

        // mouseover(): Al pasar el cursor sobre el selector destino, resalta su borde
        $to.mouseover(function () { $(this).css("border-color", "var(--orange)"); });

        // keyup(): Mientras se escribe el monto, revisa si supera el millón y avisa
        $amount.keyup(function () {
            if (parseFloat($(this).val()) > 1000000) {
                console.log("Monto elevado detectado:", $(this).val());
                $(this).css("color", "var(--amber)");
            } else {
                $(this).css("color", "var(--text)");
            }
        });

    } // fin aplicarEfectos

}); // fin ready()